﻿Public Class Cliente
    Public Property idCliente As Integer
    Public Property nombre As String
    Public Property apellido As String
    Public Property direccion As String
    Public Property zona As String
    Public Property telefono As Integer
End Class
