﻿Public Class Barrio
    Public Property ID_BARRIO As Integer
    Public Property nombre As String


End Class
