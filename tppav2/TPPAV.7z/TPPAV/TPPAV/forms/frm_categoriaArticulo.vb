﻿Public Class frm_categoriaArticulo

    Private Sub btn_clear_Click(sender As Object, e As EventArgs) Handles btn_clear.Click
        txt_nomCate.Text = String.Empty
        rtx_descripcion.Text = String.Empty


    End Sub
End Class